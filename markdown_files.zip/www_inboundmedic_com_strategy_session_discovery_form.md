[Skip to main content](https://www.inboundmedic.com/strategy-session-discovery-form/#brx-content) [Skip to footer](https://www.inboundmedic.com/strategy-session-discovery-form/#brx-footer)

Strategy Session

# Discovery Form

**You Must Fill Out This Discovery Form Completely To Confirm Your Strategy Session With Us.**

**We will cancel your call without a completely filled out and submitted Discovery form.**

**And please watch the video below.**

Inbound Medic Discovery Form

Powered by Typeform

![inbound logo small](https://images.typeform.com/images/mnJv3cCTdkiR/image/default)

# Please fill out this Discovery Form

Your call will be cancelled without completing this step.

powered by [Typeform](https://admin.typeform.com/signup?utm_campaign=yJ0QkT&utm_source=typeform.com-01E2A7GHS1JKNB84BCKK6607Z6-free&utm_medium=typeform&utm_content=typeform-embedded-poweredbytypeform&utm_term=EN)

Thank You For Scheduling Your Strategy Session With Us from Inbound Medic on Vimeo

![video thumbnail](https://i.vimeocdn.com/video/1902880753-bf44f70b20a4bde5f5ec5ca1c7f132fa2ec656f6b57155a6c0c3e59d739d9b4f-d?mw=80&q=85)

Playing in picture-in-picture

Unmute

Like

Add to Watch Later

Share

Pause

00:00

00:00

Settings

Quality1080p

Picture-in-PictureFullscreen

[Watch on Vimeo](https://vimeo.com/987274990)

![Schedule Your Free Strategy Call - Icon White - Inbound Medic](https://www.inboundmedic.com/wp-content/uploads/2024/12/Schedule-Your-Free-Strategy-Call-Icon-White-Inbound-Medic-150x150.png)

## Schedule Your Free Strategy Call

Let’s discuss your challenges in attracting new patients and growing your medical practice. In a no-pressure and judgement-free zone, we will listen carefully and help you identify the next steps to take, whether or not you choose to work with us.

[Schedule Strategy Call](https://www.inboundmedic.com/strategy-session/)

Download Our Whitepaper

## The AI Playbook For Doctors: How To Replace Traditional SEO With Scalable, AI-Powered Patient Acquisition

Google SERPs are dying. AI is deciding who gets the patient. This whitepaper reveals how platforms like ChatGPT, Gemini, Perplexity and LLMs are replacing traditional search — and why the next generation of patient acquisition won’t be won with Facebook ads, backlinks or "content marketing".

Discover what every $2M+ surgeon, doctor and private practice owner is doing right now to train AI to recommend them — and how to make your brand the default answer.

Subscription Form

URL

Download the Whitepaper

![Free Video Masterclass - Image - Inbound Medic](https://www.inboundmedic.com/wp-content/uploads/2024/12/Free-Video-Masterclass-Image-Inbound-Medic-1024x834.png)